#!/usr/bin/env python3
"""
VPS Server - Glavni poslužitelj za Ela Sport trgovinu
1. Poslužuje statički frontend (SEO optimiziran).
2. Upravlja hibridnom bazom (SQL + Vektori).
3. Prima heartbeat od Jetsona i prati njegovu IP/status.
4. Kešira LLM odgovore i routa upite prema Jetsonu kroz SSH tunnel.
5. Obrađuje narudžbe (privatna/poslovna lica).
6. Detektira jezik upita i odgovara na istom jeziku.
"""

import os
import json
import time
import sqlite3
import threading
import logging
import hashlib
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_from_directory, render_template_string
from flask_cors import CORS
import requests

# Konfiguracija
app = Flask(__name__, static_folder='.', template_folder='.')
CORS(app)  # Omogući CORS za komunikaciju s frontendom

DB_PATH = 'products.db'
VECTORS_PATH = 'vectors.json'
LOG_FILE = 'vps_server.log'
SSH_TUNNEL_PORT = 2222  # Remote port na koji Jetson spaja svoj SSH

# Postavi logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- STANJE SUSTAVA ---
# Rječnik za praćenje aktivnih Jetson uređaja
# Struktura: { "device_id": {"public_ip": "...", "ssh_port": 2222, "last_seen": datetime, "status": "online"} }
jetson_registry = {}

# LRU Cache za LLM odgovore (jednostavna implementacija u memoriji)
# Ključ: hash(upit + jezik), Vrijednost: {odgovor, timestamp, jezik}
llm_cache = {}
CACHE_TTL_SECONDS = 3600  # Keširaj odgovore 1 sat
MAX_CACHE_SIZE = 1000  # Maksimalni broj stavki u cacheu

def get_db_connection():
    """Kreira vezu na SQLite bazu."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def detect_language(text):
    """
    Detekcija jezika temeljem sadržaja teksta.
    Podržava: hr, sr, bs, en, de, it, fr, es
    """
    text_lower = text.lower()
    
    # Cyrillic detection (Serbian, Bulgarian, Macedonian)
    cyrillic_chars = set('абвгдежзийклмнопрстуфхцчшщъыьэюяђњћџ')
    if any(c in text_lower for c in cyrillic_chars):
        return 'sr'
    
    # Language-specific keywords
    lang_indicators = {
        'hr': ['što', 'gdje', 'kada', 'zašto', 'kako', 'molim', 'hvala', 'dobar', 'lijep'],
        'bs': ['šta', 'gdje', 'kada', 'zašto', 'kako', 'molim', 'hvala'],
        'sr': ['šta', 'gde', 'kada', 'zašto', 'kako', 'molim', 'hvala'],
        'en': ['what', 'where', 'when', 'why', 'how', 'please', 'thank', 'good'],
        'de': ['was', 'wo', 'wann', 'warum', 'wie', 'bitte', 'danke', 'gut'],
        'it': ['cosa', 'dove', 'quando', 'perché', 'come', 'per favore', 'grazie'],
        'fr': ['quoi', 'où', 'quand', 'pourquoi', 'comment', 's\'il', 'merci'],
        'es': ['qué', 'dónde', 'cuándo', 'por qué', 'cómo', 'por favor', 'gracias']
    }
    
    scores = {lang: 0 for lang in lang_indicators.keys()}
    
    for lang, indicators in lang_indicators.items():
        for indicator in indicators:
            if indicator in text_lower:
                scores[lang] += 1
    
    # Return language with highest score, default to 'hr'
    best_lang = max(scores, key=scores.get)
    if scores[best_lang] > 0:
        return best_lang
    
    return 'hr'  # Default

def generate_cache_key(query, language):
    """Generira jedinstveni ključ za cache."""
    return hashlib.md5(f"{query}_{language}".encode()).hexdigest()

def get_cached_response(cache_key):
    """Dohvaća odgovor iz cachea ako postoji i nije istekao."""
    if cache_key in llm_cache:
        entry = llm_cache[cache_key]
        if time.time() - entry['timestamp'] < CACHE_TTL_SECONDS:
            logger.info(f"CACHE HIT za ključ: {cache_key[:12]}...")
            return entry['response'], entry['language']
        else:
            del llm_cache[cache_key]  # Isteklo
            logger.info(f"CACHE EXPIRED za ključ: {cache_key[:12]}...")
    return None, None

def save_to_cache(cache_key, response, language):
    """Sprema odgovor u cache s LRU logikom."""
    # Ako je cache pun, ukloni najstariju stavku
    if len(llm_cache) >= MAX_CACHE_SIZE:
        oldest_key = min(llm_cache.keys(), key=lambda k: llm_cache[k]['timestamp'])
        del llm_cache[oldest_key]
        logger.info(f"LRU eviction: uklonjen ključ {oldest_key[:12]}...")
    
    llm_cache[cache_key] = {
        'response': response,
        'language': language,
        'timestamp': time.time()
    }
    logger.info(f"CACHE MISS - Spremljen novi odgovor za ključ: {cache_key[:12]}...")

def get_active_jetson():
    """Pronalazi aktivni Jetson uređaj."""
    now = datetime.now()
    for device_id, info in jetson_registry.items():
        # Ako je viđen u zadnjih 90 sekundi, smatramo ga aktivnim
        if (now - info['last_seen']).total_seconds() < 90:
            return device_id, info
    return None, None

# --- API ENDPOINTS ---

@app.route('/api/jetson/heartbeat', methods=['POST'])
def receive_heartbeat():
    """Prima heartbeat signal od Jetson agenta s javnom IP adresom."""
    data = request.json
    device_id = data.get('jetson_id')  # Prilagođeno jetson_agent.py
    public_ip = data.get('public_ip')
    ssh_port = data.get('ssh_port', SSH_TUNNEL_PORT)
    status = data.get('status', 'online')
    
    if not device_id or not public_ip:
        return jsonify({"error": "Missing jetson_id or public_ip"}), 400
    
    # Ažuriraj registry s trenutnom IP adresom Jetsona
    jetson_registry[device_id] = {
        'public_ip': public_ip,
        'ssh_port': ssh_port,
        'last_seen': datetime.now(),
        'status': status
    }
    
    logger.info(f"Heartbeat primljen od {device_id} | IP: {public_ip} | SSH Port: {ssh_port}")
    return jsonify({"status": "ok", "message": "Heartbeat received", "device_id": device_id})

@app.route('/api/chat', methods=['POST'])
def chat_endpoint():
    """Glavni endpoint za chat s AI trgovcem."""
    data = request.json
    user_query = data.get('query', '')
    user_lang = data.get('language', None)  # Ako frontend već detektira
    
    if not user_query:
        return jsonify({"error": "Query is required"}), 400

    # 1. Detekcija jezika ako nije proslijeđena
    if not user_lang:
        user_lang = detect_language(user_query)
        logger.info(f"Detektiran jezik: {user_lang} za upit: {user_query[:50]}...")
    
    # 2. Provjera cachea (ključ = hash(upit + jezik))
    cache_key = generate_cache_key(user_query, user_lang)
    cached_resp, cached_lang = get_cached_response(cache_key)
    if cached_resp:
        return jsonify({
            "response": cached_resp,
            "source": "cache",
            "language": cached_lang
        })

    # 3. Pronađi aktivni Jetson
    device_id, jetson = get_active_jetson()
    
    if not jetson:
        # Fallback logika ako Jetson nije dostupan
        logger.warning("Jetson nije dostupan. Vraćam fallback odgovor.")
        fallback_responses = {
            'hr': "Trenutno naš AI asistent nije dostupan zbog održavanja sustava. Molimo pokušajte kasnije ili pregledajte našu ponudu.",
            'en': "Our AI assistant is currently unavailable due to system maintenance. Please try again later or browse our catalog.",
            'de': "Unser KI-Assistent ist derzeit wegen Wartungsarbeiten nicht verfügbar. Bitte versuchen Sie es später erneut.",
            'sr': "Тренутно наш АИ асистент није доступан због одржавања система. Молимо покушајте касније или прегледајте нашу понуду.",
        }
        fallback_response = fallback_responses.get(user_lang, fallback_responses['en'])
        
        # Spremi fallback u cache na kraće vrijeme (5 minuta)
        temp_cache_key = generate_cache_key(user_query, user_lang)
        save_to_cache(temp_cache_key, fallback_response, user_lang)
        # Override TTL for fallback (hack: manually adjust timestamp)
        llm_cache[temp_cache_key]['timestamp'] = time.time() - 3540  # Ističe za 60 sekundi
        
        return jsonify({
            "response": fallback_response,
            "source": "fallback",
            "language": user_lang
        })

    # 4. Proslijedi upit na Jetson kroz SSH Tunnel
    # Reverse SSH tunnel omogućuje da VPS spoji na localhost:SSH_TUNNEL_PORT (2222)
    # što je zapravo SSH port na Jetsonu. Zatim preko toga ide HTTP zahtjev.
    
    try:
        # Opcija A: Kroz SSH tunnel (preporučeno)
        # Pretpostavka: Na Jetsonu je pokrenut mali HTTP server na portu 8000
        # SSH komanda na Jetsonu: ssh -R 2222:localhost:8000 vps-user@vps-ip
        # Onda na VPS-u: http://localhost:2222/generate NE radi direktno jer je to SSH port
        # Treba nam HTTP port koji je tuneliran. Recimo da Jetson tunelira svoj 8000 na VPS 8000.
        
        # Ispravna pretpostavka: Jetson koristi -R 8000:localhost:8000
        # Onda VPS spaja na http://localhost:8000/generate
        local_tunnel_url = f"http://127.0.0.1:8000/generate" 
        
        payload = {
            "query": user_query,
            "language": user_lang,
            "context": "trgovina_sportskom_opremom",
            "products_db_hint": "hibridna_sql_vector"  # Hint za Jetson koju bazu koristiti
        }
        
        logger.info(f"Šaljem upit na Jetson (tunnel): {local_tunnel_url}")
        resp = requests.post(local_tunnel_url, json=payload, timeout=15)
        resp.raise_for_status()
        ai_response_data = resp.json()
        ai_response = ai_response_data.get('response', '')
        
        # 5. Spremi u cache
        save_to_cache(cache_key, ai_response, user_lang)
        
        return jsonify({
            "response": ai_response,
            "source": "jetson",
            "language": user_lang,
            "device_id": device_id
        })
        
    except requests.exceptions.ConnectionError as e:
        logger.error(f"Connection error pri komunikaciji s Jetsonom: {e}")
        error_response_map = {
            'hr': "Došlo je do tehničke pogreške pri povezivanju s asistentom. Pokušajte ponovno.",
            'en': "Technical error connecting to the assistant. Please try again.",
            'de': "Technischer Fehler bei der Verbindung zum Assistenten. Bitte versuchen Sie es erneut."
        }
        error_response = error_response_map.get(user_lang, error_response_map['en'])
        return jsonify({
            "response": error_response,
            "source": "connection_error",
            "language": user_lang
        }), 503
    except Exception as e:
        logger.error(f"Greška pri komunikaciji s Jetsonom: {e}")
        error_response_map = {
            'hr': "Došlo je do neočekivane pogreške.",
            'en': "An unexpected error occurred.",
            'de': "Ein unerwarteter Fehler ist aufgetreten."
        }
        error_response = error_response_map.get(user_lang, error_response_map['en'])
        return jsonify({
            "response": error_response,
            "source": "error",
            "language": user_lang
        }), 503

@app.route('/api/products/search', methods=['GET'])
def search_products():
    """Pretraživanje proizvoda (SQL + Vektorska hibridna pretraga)."""
    query = request.args.get('q', '')
    category = request.args.get('category', '')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Osnovna SQL pretraga
    sql = "SELECT * FROM products WHERE 1=1"
    params = []
    
    if query:
        sql += " AND (name LIKE ? OR description LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%"])
    
    if category:
        sql += " AND category = ?"
        params.append(category)
        
    sql += " LIMIT 20"
    
    cursor.execute(sql, params)
    rows = cursor.fetchall()
    conn.close()
    
    products = [dict(row) for row in rows]
    
    # OVDJE BI IŠLA LOGIKA ZA VEKTORSKU PRETRAGU AKO SQL VRATI MALO REZULTATA
    # 1. Generiraj vektor upita (lokalno mali model ili poziv Jetsonu)
    # 2. Traži najbliže susjede u vectors.json / FAISS indexu
    # 3. Spoji rezultate
    
    return jsonify(products)

@app.route('/api/orders', methods=['POST'])
def create_order():
    """Kreiranje nove narudžbe."""
    data = request.json
    # Validacija podataka (pojednostavljeno)
    required_fields = ['customer_type', 'customer_data', 'items']
    if not all(field in data for field in required_fields):
        return jsonify({"error": "Missing required fields"}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Ubaci narudžbu
        cursor.execute("""
            INSERT INTO orders (customer_type, customer_json, items_json, total_amount, status, created_at)
            VALUES (?, ?, ?, ?, 'pending', ?)
        """, (
            data['customer_type'],
            json.dumps(data['customer_data']),
            json.dumps(data['items']),
            data.get('total_amount', 0.0),
            datetime.now()
        ))
        order_id = cursor.lastrowid
        conn.commit()
        
        # Ovdje dodati slanje emaila trgovcu/kupcu
        
        return jsonify({"success": True, "order_id": order_id}), 201
        
    except Exception as e:
        conn.rollback()
        logger.error(f"Greška pri kreiranju narudžbe: {e}")
        return jsonify({"error": "Database error"}), 500
    finally:
        conn.close()

# --- SERVINg FRONTENDA ---

@app.route('/')
def serve_index():
    """Poslužuje glavnu HTML stranicu."""
    # U produkciji, ovo bi bio statički file iz 'static' mape
    # ili generirani HTML iz SEO procesa
    return send_from_directory('.', 'index.html')

@app.route('/product/<int:product_id>')
def serve_product_seo(product_id):
    """
    SEO Endpoint: Generira statički HTML za specifičan proizvod.
    Ovo vide samo Google botovi (ili se renderira SSR), 
    a korisnicima se može poslužiti isti sadržaj ili SPA.
    """
    conn = get_db_connection()
    product = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
    conn.close()
    
    if not product:
        return "Proizvod nije pronađen", 404
        
    # Generiraj HTML s meta tagovima za SEO
    html_content = f"""
    <!DOCTYPE html>
    <html lang="hr">
    <head>
        <meta charset="UTF-8">
        <title>{product['name']} - Ela Sport</title>
        <meta name="description" content="{product['description'][:160]}">
        <meta property="og:title" content="{product['name']}">
        <meta property="og:image" content="/images/{product['image']}">
        <!-- Ostali SEO tagovi -->
    </head>
    <body>
        <!-- Sadržaj proizvoda vidljiv i botovima i ljudima -->
        <h1>{product['name']}</h1>
        <p>Cijena: {product['price']} EUR</p>
        <p>{product['description']}</p>
        <script>
            // Ovdje se učitava React/Vue/JS aplikacija za interaktivnost
            window.PRODUCT_DATA = {json.dumps(dict(product))};
        </script>
    </body>
    </html>
    """
    return html_content

if __name__ == '__main__':
    logger.info("Pokretanje VPS Servera...")
    # Pokreni server na svim interfejsima, port 5000
    app.run(host='0.0.0.0', port=5000, debug=True)
