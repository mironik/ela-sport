# Ela Sport - Hibridna AI Trgovina

## Arhitektura Sustava

Ovaj projekt sadrži kompletan sustav za modernu web trgovinu s AI asistentom:

- **VPS Server**: Hosta frontend, API, bazu podataka i kešira odgovore
- **Jetson Orin Nano**: Pokreće LLM model za prirodno jezično sučelje
- **Hibridna baza**: Kombinacija SQL (strukturirani podaci) i vektorske pretrage (semantika)

## Struktura Datoteka

```
ela-sport/
├── index.html              # Frontend web trgovine
├── server.py               # VPS backend (API, cache, narudžbe)
├── jetson_agent.py         # AI agent na Jetson uređaju
├── create_hybrid_db.py     # Skripta za kreiranje hibridne baze
├── products.db             # SQLite baza podataka
├── vectors.json            # Tekstualni podaci za vektorizaciju
├── baza.csv                # Izvorni podaci o proizvodima
├── requirements.txt        # Python dependecies
└── README.md               # Ova datoteka
```

## Instalacija

### 1. Na VPS Serveru

```bash
# Instalacija dependeciesa
pip install -r requirements.txt

# Pokretanje servera
python server.py
```

Server će se pokrenuti na portu 5000 (ili drugom po izboru).

### 2. Na Jetson Orin Nano Uređaju

```bash
# Instalacija dependeciesa (uključujući PyTorch za lokalni LLM)
pip install -r requirements.txt

# Konfiguracija
export VPS_IP="vasa.vps.adresa.com"
export VPS_PORT=22
export VPS_USER="vps_korisnik"

# Pokretanje agenta
python jetson_agent.py
```

Agent će automatski:
- Detektirati svoju javnu IP adresu
- Uspostaviti reverse SSH tunnel s VPS-om
- Slati heartbeat signale svakih 30 sekundi
- Pokrenuti lokalni HTTP server za AI inferencu

## Funkcionalnosti

### 🌐 Višejezična Podrška
Sustav automatski detektira jezik upita i odgovara na istom jeziku:
- Hrvatski, Srpski, Bošnjački
- Engleski, Njemački, Talijanski, Francuski, Španjolski

### 🧠 AI Asistent (LLM)
- Prirodno jezično sučelje za pretragu proizvoda
- Semantičko razumijevanje upita ("trebam tenisice za trčanje do 100€")
- Kontekstualni odgovori temeljeni na dostupnim proizvodima

### 💾 Hibridna Baza Podataka
- **SQL dio**: Brza pretraga po kategorijama, cijenama, zalihama
- **Vektorski dio**: Semantička pretraga opisa i naziva proizvoda

### 🚀 Optimizacije
- **Keširanje odgovora**: Identical queries vraćaju keširane odgovore
- **Fallback logika**: Ako Jetson nije dostupan, koriste se unaprijed definirani odgovori
- **Heartbeat sustav**: VPS uvijek zna trenutnu lokaciju Jetsona (dinamička IP)

### 🛒 Narudžbe
- **Privatna lica**: Dostava + plaćanje pouzećem
- **Poslovna lica**: Narudžba + bankovna uplata
- **Budući modul**: Kartično plaćanje (pripremljena infrastruktura)

### 🔍 SEO Optimizacija
- Generiranje statičkih HTML stranica za Google indeksiranje
- Stranice su nevidljive korisnicima, ali vidljive tražilicama

## Reverse SSH Tunnel

Komunikacija između VPS-a i Jetsona odvija se kroz reverse SSH tunnel:

```bash
# Jetson pokreće:
ssh -R 8000:localhost:8000 user@vps-ip -N

# VPS se spaja na:
localhost:8000 -> Jetson:8000
```

Ovo omogućuje VPS-u pristup Jetsonu čak i kada je Jetson iza NAT-a ili ima dinamičku IP.

## API Endpoints

### VPS Server (`server.py`)

| Endpoint | Metoda | Opis |
|----------|--------|------|
| `/api/chat` | POST | Pošalji upit AI asistentu |
| `/api/search` | POST | Pretraži proizvode (SQL + vektori) |
| `/api/order` | POST | Kreiraj novu narudžbu |
| `/api/heartbeat` | POST | Primi heartbeat od Jetsona |
| `/api/products` | GET | Dohvati listu proizvoda |
| `/api/product/<id>` | GET | Dohvati detalje proizvoda |

### Jetson Agent (`jetson_agent.py`)

| Endpoint | Metoda | Opis |
|----------|--------|------|
| `/ai/generate` | POST | Generiraj odgovor na upit |
| `/ai/embed` | POST | Generiraj vektor za tekst |

## Konfiguracija

### Environment Varijable (VPS)

```bash
export DATABASE_URL="sqlite:///products.db"
export CACHE_SIZE=1000
export SECRET_KEY="vasa_tajna_lozinka"
export SMTP_SERVER="smtp.gmail.com"
export SMTP_PORT=587
export SMTP_USER="vasa@email.com"
export SMTP_PASS="lozinka"
```

### Environment Varijable (Jetson)

```bash
export MODEL_PATH="/path/to/local/llm"
export DEVICE="cuda"  # ili "cpu"
export MAX_TOKENS=512
export VPS_IP="vasa.vps.adresa.com"
export VPS_SSH_PORT=22
export VPS_SSH_USER="korisnik"
```

## Sigurnosne Napomene

1. **SSH Ključevi**: Koristite SSH ključeve umjesto lozinki za tunnel
2. **Firewall**: Ograničite pristup samo na potrebne portove
3. **HTTPS**: U produkciji koristite HTTPS s validnim certifikatom
4. **Rate Limiting**: Implementiran je na API endpointima

## Buduća Proširenja

- [ ] Modul za kartično plaćanje (Corvus, Stripe, PayPal)
- [ ] Admin panel za upravljanje narudžbama i proizvodima
- [ ] SMS notifikacije za status narudžbe
- [ ] Integracija s dostavnim službama (GLS, DHL, HP)
- [ ] Analytics dashboard za praćenje prodaje

## Licenca

Ovaj projekt je vlasništvo Ela Sport trgovine. Sva prava pridržana.

## Kontakt

Za tehničku podršku obratite se na: support@elasport.hr
