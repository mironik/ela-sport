#!/usr/bin/env python3
"""
Konverzija WooCommerce CSV u hibridnu bazu (SQL + Vectors)
Namijenjeno za Ela Sport trgovinu

Struktura:
- products.db: SQLite baza za strukturirane podatke i SQL upite
- vectors.json: JSON s tekstualnim podacima spremnim za vektorizaciju na Jetsonu
"""

import csv
import sqlite3
import json
import re
from pathlib import Path

def clean_text(text):
    """Čišćenje HTML tagova i viška whitespacea"""
    if not text or text == '':
        return ''
    # Ukloni HTML tagove
    text = re.sub(r'<[^>]+>', '', text)
    # Ukloni HTML entitete
    text = text.replace('&nbsp;', ' ')
    text = text.replace('\\n', ' ')
    # Sredi višestruke razmake
    text = ' '.join(text.split())
    return text.strip()

def parse_categories(cat_string):
    """Parsiranje kategorija iz 'ODJEĆA > Jakne, ODJEĆA' u listu"""
    if not cat_string:
        return []
    # Podijeli po zarezima
    cats = [c.strip() for c in cat_string.split(',')]
    return cats

def parse_attributes(row):
    """Ekstrakcija atributa (boja, veličina) iz rowa"""
    attributes = {}
    
    # Provjeri stupce za atribute
    attr1_name = row.get('Atribut 1 ime') or ''
    attr1_name = attr1_name.strip()
    attr1_values = row.get('Atribut 1 vrijednosti') or ''
    attr1_values = attr1_values.strip()
    
    if attr1_name and attr1_values:
        values = [v.strip() for v in attr1_values.split(',')]
        attributes[attr1_name] = values
    
    attr2_name = row.get('Atribut 2 ime') or ''
    attr2_name = attr2_name.strip()
    attr2_values = row.get('Atribut 2 vrijednosti') or ''
    attr2_values = attr2_values.strip()
    
    if attr2_name and attr2_values:
        values = [v.strip() for v in attr2_values.split(',')]
        attributes[attr2_name] = values
    
    return attributes

def parse_variations(json_str):
    """Parsiranje JSON stringa varijacija"""
    if not json_str:
        return {}
    try:
        # Ponekad JSON ima escapeane navodnike
        json_str = json_str.replace('\\"', '"')
        return json.loads(json_str)
    except:
        return {}

def create_database(csv_path, db_path, vectors_path):
    """Glavna funkcija za kreiranje hibridne baze"""
    
    # Čitanje CSV datoteke
    products = []
    variations_map = {}  # parent_id -> [variation_ids]
    
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
            
            # Mapiraj varijacije na roditelje
            product_type = row.get('Vrsta', '')
            if product_type == 'variation':
                parent_id = row.get('Objavljeno', '')  # Ovo treba provjeriti
                # U WooCommerce, varijacije imaju parent ID u nekom stupcu
                # Provjerit ćemo ID proizvoda
    
    # Kreiranje SQLite baze
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Tablica proizvoda
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY,
            sku TEXT,
            name TEXT NOT NULL,
            type TEXT,
            short_description TEXT,
            description TEXT,
            price_normal REAL,
            price_sale REAL,
            stock_quantity INTEGER,
            stock_status TEXT,
            categories TEXT,
            tags TEXT,
            images TEXT,
            weight REAL,
            length REAL,
            width REAL,
            height REAL,
            attributes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Tablica za varijacije proizvoda
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS variations (
            id INTEGER PRIMARY KEY,
            parent_id INTEGER,
            sku TEXT,
            name TEXT,
            price_normal REAL,
            price_sale REAL,
            stock_quantity INTEGER,
            attributes TEXT,
            image TEXT,
            FOREIGN KEY (parent_id) REFERENCES products(id)
        )
    ''')
    
    # Tablica za kategorije (normalizirana)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            slug TEXT
        )
    ''')
    
    # Tablica za pretragu (denormalizirana za bržu pretragu)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS search_index (
            product_id INTEGER,
            search_text TEXT,
            categories TEXT,
            tags TEXT,
            name TEXT,
            sku TEXT,
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    ''')
    
    # Kreiranje indeksa za bržu pretragu
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_products_categories ON products(categories)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_search_text ON search_index(search_text)')
    
    # Obrada proizvoda
    vector_data = []  # Za vektorsku bazu
    category_set = set()
    
    for row in products:
        product_id = int(row['ID']) if row['ID'] else None
        if not product_id:
            continue
            
        product_type = row.get('Vrsta', 'simple')
        
        # Osnovni podaci
        name = clean_text(row.get('Naziv', ''))
        sku = row.get('SKU', '')
        short_desc = clean_text(row.get('Kratak opis', ''))
        description = clean_text(row.get('Opis', ''))
        
        # Cijene
        price_normal = float(row.get('Normalna cijena', 0) or 0)
        price_sale = float(row.get('Rasprodajna cijena', 0) or 0)
        
        # Zalihe
        stock_qty = int(row.get('Zalihe', 0) or 0)
        stock_status = 'instock' if row.get('Na zalihi?', '0') == '1' else 'outofstock'
        
        # Kategorije i oznake
        categories = parse_categories(row.get('Kategorije', ''))
        tags = row.get('Oznake', '').split(',') if row.get('Oznake') else []
        categories = [c for c in categories if c]
        tags = [t.strip() for t in tags if t.strip()]
        
        # Dimenzije
        weight = float(row.get('Težina (kg)', 0) or 0)
        length = float(row.get('Dužina (cm)', 0) or 0)
        width = float(row.get('Širina (cm)', 0) or 0)
        height = float(row.get('Visina (cm)', 0) or 0)
        
        # Slike
        images = row.get('Slike', '')
        
        # Atributi
        attributes = parse_attributes(row)
        
        # Spremi kategorije
        for cat in categories:
            category_set.add(cat)
        
        if product_type in ['simple', 'variable']:
            # Glavni proizvod
            cursor.execute('''
                INSERT OR REPLACE INTO products 
                (id, sku, name, type, short_description, description, 
                 price_normal, price_sale, stock_quantity, stock_status,
                 categories, tags, images, weight, length, width, height, attributes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                product_id, sku, name, product_type, short_desc, description,
                price_normal, price_sale, stock_qty, stock_status,
                json.dumps(categories, ensure_ascii=False),
                json.dumps(tags, ensure_ascii=False),
                images, weight, length, width, height,
                json.dumps(attributes, ensure_ascii=False)
            ))
            
            # Kreiraj search tekst
            search_text = f"{name} {short_desc} {description}".lower()
            cursor.execute('''
                INSERT INTO search_index (product_id, search_text, categories, tags, name, sku)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                product_id, search_text,
                json.dumps(categories, ensure_ascii=False),
                json.dumps(tags, ensure_ascii=False),
                name.lower(),
                sku.lower() if sku else ''
            ))
            
            # Pripremi podatke za vektore
            vector_entry = {
                'id': product_id,
                'type': 'product',
                'text': f"{name}. {short_desc}. {description}. Kategorije: {', '.join(categories)}.",
                'metadata': {
                    'name': name,
                    'categories': categories,
                    'price': price_normal if price_normal > 0 else price_sale,
                    'sku': sku
                }
            }
            vector_data.append(vector_entry)
            
        elif product_type == 'variation':
            # Varijacija proizvoda
            # Pronađi parent ID - u WooCommerce exportu to može biti u različitim stupcima
            # Obično se vidi iz naziva ili iz "Grupirani proizvodi"
            parent_match = re.search(r'id:(\d+)', row.get('Grupirani proizvodi', '') or '')
            if not parent_match:
                # Pokušaj ekstrahirati iz naziva
                parent_match = re.search(r'id:(\d+)', row.get('Napomena uz kupovinu', '') or '')
            
            parent_id = int(parent_match.group(1)) if parent_match else None
            
            # Ekstrahiraj atribut varijacije
            var_attr_name = row.get('Atribut 1 ime', '')
            var_attr_value = row.get('Atribut 1 vrijednosti', '')
            
            var_attributes = {}
            if var_attr_name and var_attr_value:
                var_attributes[var_attr_name] = var_attr_value
            
            cursor.execute('''
                INSERT OR REPLACE INTO variations
                (id, parent_id, sku, name, price_normal, price_sale, stock_quantity, attributes, image)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                product_id, parent_id, sku, name,
                price_normal, price_sale, stock_qty,
                json.dumps(var_attributes, ensure_ascii=False),
                images
            ))
    
    # Spremi kategorije
    for cat in category_set:
        slug = cat.lower().replace(' ', '-').replace('>', '-').strip('-')
        cursor.execute('''
            INSERT OR IGNORE INTO categories (name, slug) VALUES (?, ?)
        ''', (cat, slug))
    
    conn.commit()
    conn.close()
    
    # Spremi vektorske podatke u JSON
    with open(vectors_path, 'w', encoding='utf-8') as f:
        json.dump({
            'version': '1.0',
            'generated_at': str(Path(csv_path).stat().st_mtime),
            'total_products': len(vector_data),
            'data': vector_data
        }, f, ensure_ascii=False, indent=2)
    
    print(f"✓ Kreirana SQLite baza: {db_path}")
    print(f"✓ Kreiran vectors JSON: {vectors_path}")
    print(f"✓ Ukupno proizvoda: {len(vector_data)}")
    print(f"✓ Ukupno kategorija: {len(category_set)}")
    
    # Ispiši statistiku
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM products")
    print(f"✓ Produkata u bazi: {cursor.fetchone()[0]}")
    cursor.execute("SELECT COUNT(*) FROM variations")
    print(f"✓ Varijacija u bazi: {cursor.fetchone()[0]}")
    conn.close()

if __name__ == '__main__':
    # Putanje
    base_dir = Path(__file__).parent
    csv_path = base_dir / 'baza.csv'
    db_path = base_dir / 'products.db'
    vectors_path = base_dir / 'vectors.json'
    
    if not csv_path.exists():
        print(f"Greška: CSV datoteka nije pronađena: {csv_path}")
        exit(1)
    
    create_database(csv_path, db_path, vectors_path)
    print("\nHibridna baza uspješno kreirana!")
    print("\nSljedeći koraci:")
    print("1. Kopiraj vectors.json na Jetson Orin Nano")
    print("2. Generiraj vektore pomoću lokalnog embedding modela")
    print("3. Spremi vektore u vektorsku bazu (npr. Chroma, FAISS, ili Qdrant)")
    print("4. Postavi server.py na VPS za API komunikaciju")
