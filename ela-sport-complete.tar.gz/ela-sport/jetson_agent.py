#!/usr/bin/env python3
"""
Jetson Orin Nano Agent
- Detektira javnu IP adresu
- Uspostavlja reverse SSH tunnel prema VPS-u
- Šalje heartbeat signale svakih 30 sekundi
- Pokreće lokalni HTTP server za AI inference (port 8000)
- Obrađuje upite od VPS-a kroz LLM model
"""

import requests
import time
import json
import socket
import subprocess
import threading
import os
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

# Konfiguracija
VPS_HOST = os.getenv("VPS_HOST", "tvoj-vps-domain.com")
VPS_PORT = int(os.getenv("VPS_PORT", "5000"))
SSH_REMOTE_PORT = int(os.getenv("SSH_REMOTE_PORT", "2222"))
HTTP_SERVER_PORT = 8000  # Port za AI inference HTTP server
HEARTBEAT_INTERVAL = 30  # sekunde
JETSON_ID = os.getenv("JETSON_ID", "jetson-001")

app = Flask(__name__)
CORS(app)

# --- GLOBALNO STANJE ---
jetson_public_ip = "unknown"
llm_model = None  # Ovdje će biti učitani TensorRT/ONNX model

def get_public_ip():
    """Detektira javnu IP adresu koristeći vanjske servise"""
    services = [
        "https://api.ipify.org?format=json",
        "https://ipapi.co/json/",
        "https://ifconfig.me/ip"
    ]
    
    for service in services:
        try:
            if "json" in service:
                response = requests.get(service, timeout=5)
                data = response.json()
                if "ip" in data:
                    return data["ip"]
            else:
                response = requests.get(service, timeout=5)
                return response.text.strip()
        except Exception as e:
            print(f"[{datetime.now()}] Greška pri dohvatu IP s {service}: {e}")
            continue
    
    # Fallback: lokalna IP ako svi vanjski servisi failaju
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except:
        return "127.0.0.1"

def send_heartbeat():
    """Šalje heartbeat signal VPS-u s trenutnom IP adresom"""
    global jetson_public_ip
    public_ip = get_public_ip()
    jetson_public_ip = public_ip
    
    payload = {
        "jetson_id": JETSON_ID,
        "public_ip": public_ip,
        "timestamp": datetime.now().isoformat(),
        "status": "online",
        "ssh_port": SSH_REMOTE_PORT
    }
    
    try:
        response = requests.post(
            f"http://{VPS_HOST}:{VPS_PORT}/api/jetson/heartbeat",
            json=payload,
            timeout=10
        )
        if response.status_code == 200:
            print(f"[{datetime.now()}] ✓ Heartbeat poslan: IP={public_ip}")
            return True
        else:
            print(f"[{datetime.now()}] ✗ Greška heartbeat: {response.status_code}")
            return False
    except Exception as e:
        print(f"[{datetime.now()}] ✗ Heartbeat neuspješan: {e}")
        return False

def establish_ssh_tunnel():
    """Uspostavlja reverse SSH tunnel prema VPS-u"""
    # Napomena: Ovo zahtijeva SSH ključeve postavljene unaprijed
    # Generiraj SSH ključ na Jetsonu: ssh-keygen -t ed25519
    # Dodaj javni ključ na VPS: ~/.ssh/authorized_keys
    
    ssh_cmd = [
        "ssh",
        "-o", "StrictHostKeyChecking=no",
        "-o", "ServerAliveInterval=60",
        "-o", "ServerAliveCountMax=3",
        "-o", "ExitOnForwardFailure=yes",
        "-R", f"{HTTP_SERVER_PORT}:localhost:{HTTP_SERVER_PORT}",  # Tuneliraj HTTP port
        f"vps-user@{VPS_HOST}",
        "-N"  # Ne izvršavaj udaljenu komandu, samo tunnel
    ]
    
    print(f"[{datetime.now()}] Pokrećem SSH tunnel na {VPS_HOST}...")
    try:
        process = subprocess.Popen(
            ssh_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        return process
    except Exception as e:
        print(f"[{datetime.now()}] ✗ Greška pri pokretanju SSH tunela: {e}")
        return None

def load_llm_model():
    """Učitava LLM model (TensorRT/ONNX) - placeholder"""
    global llm_model
    print(f"[{datetime.now()}] Učitavanje LLM modela...")
    # OVDJE IDE KOD ZA UČITAVANJE MODELA
    # Primjer s Transformers + ONNX ili TensorRT
    # from transformers import AutoModelForCausalLM, AutoTokenizer
    # llm_model = AutoModelForCausalLM.from_pretrained("model-path")
    llm_model = {"status": "loaded", "model_type": "placeholder"}
    print(f"[{datetime.now()}] ✓ Model učitan")

def generate_ai_response(query, language, context):
    """Generira AI odgovor koristeći lokalni model"""
    global llm_model
    
    # Placeholder logika - zamijeniti s pravim LLM inferencom
    responses = {
        'hr': f"Dobar dan! Kao AI trgovac, mogu vam pomoći s odabirom sportske opreme. Tražili ste: '{query}'. Imamo širok izbor u kategoriji {context}.",
        'en': f"Hello! As an AI shop assistant, I can help you choose sports equipment. You searched for: '{query}'. We have a wide selection in {context}.",
        'de': f"Guten Tag! Als KI-Verkäufer kann ich Ihnen bei der Auswahl von Sportgeräten helfen. Sie suchten nach: '{query}'. Wir haben eine große Auswahl in {context}.",
        'sr': f"Добар дан! Као АИ трговац, могу вам помоћи око избора спортске опреме. Тражили сте: '{query}'. Имамо широк избор у категорији {context}."
    }
    
    return responses.get(language, responses['en'])

# --- HTTP ENDPOINTS ZA AI INFERENCE ---

@app.route('/generate', methods=['POST'])
def ai_generate():
    """Endpoint za AI generiranje odgovora"""
    try:
        data = request.json
        query = data.get('query', '')
        language = data.get('language', 'hr')
        context = data.get('context', 'trgovina')
        
        print(f"[{datetime.now()}] 📩 Primen upit: {query[:50]}... (jezik: {language})")
        
        # Generiraj odgovor
        response_text = generate_ai_response(query, language, context)
        
        print(f"[{datetime.now()}] 📤 Šaljem odgovor: {response_text[:50]}...")
        
        return jsonify({
            "response": response_text,
            "language": language,
            "model": "jetson-llm-v1",
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"[{datetime.now()}] ✗ Greška u AI generiranju: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "jetson_id": JETSON_ID,
        "public_ip": jetson_public_ip,
        "model_loaded": llm_model is not None,
        "timestamp": datetime.now().isoformat()
    })

def heartbeat_thread_func():
    """Thread funkcija za slanje heartbeatova"""
    while True:
        time.sleep(HEARTBEAT_INTERVAL)
        send_heartbeat()

def main():
    print(f"\n{'='*60}")
    print(f"Jetson Orin Nano Agent - Ela Sport")
    print(f"{'='*60}")
    print(f"VPS: {VPS_HOST}:{VPS_PORT}")
    print(f"HTTP Server Port: {HTTP_SERVER_PORT}")
    print(f"SSH Remote Port: {SSH_REMOTE_PORT}")
    print(f"Jetson ID: {JETSON_ID}")
    print(f"{'='*60}\n")
    
    # Učitaj LLM model
    load_llm_model()
    
    # Prvi heartbeat prije pokretanja tunela
    send_heartbeat()
    
    # Pokreni SSH tunnel u pozadinskoj niti
    tunnel_process = establish_ssh_tunnel()
    if tunnel_process is None:
        print("[ERROR] ✗ SSH tunnel se nije mogao uspostaviti!")
        print("Nastavljam s lokalnim HTTP serverom bez tunela...")
    
    # Pokreni heartbeat thread
    hb_thread = threading.Thread(target=heartbeat_thread_func, daemon=True)
    hb_thread.start()
    
    # Pokreni HTTP server za AI inference
    print(f"\n[{datetime.now()}] Pokrećem HTTP server na portu {HTTP_SERVER_PORT}...")
    print(f"[{datetime.now()}] Endpoint: http://localhost:{HTTP_SERVER_PORT}/generate")
    print(f"[{datetime.now()}] Health check: http://localhost:{HTTP_SERVER_PORT}/health\n")
    
    try:
        app.run(host='0.0.0.0', port=HTTP_SERVER_PORT, debug=False, threaded=True)
    except KeyboardInterrupt:
        print(f"\n[{datetime.now()}] Zaustavljanje Jetson Agenta...")
    finally:
        if tunnel_process and tunnel_process.poll() is None:
            tunnel_process.terminate()

if __name__ == "__main__":
    main()
